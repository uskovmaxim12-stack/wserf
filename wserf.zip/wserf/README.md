# wserf — установка (один раз, ~10 минут, бесплатно)
1. supabase.com → New project (регион любой). Дождитесь создания.
2. Откройте `supabase/schema.sql`, замените `ЗАМЕНИТЕ@НА-СВОЮ.ПОЧТУ` на свою почту, вставьте весь файл в Supabase → SQL Editor → Run.
3. Supabase → Authentication → Providers → Email → выключите «Confirm email» (иначе пользователям придётся подтверждать почту).
4. Supabase → Project Settings → API: скопируйте Project URL и anon public key в `assets/js/config.js`. service_role НЕ вставлять.
5. Загрузите содержимое папки wserf в репозиторий GitHub → Settings → Pages → Deploy from branch (main, root).
6. Supabase → Authentication → URL Configuration: Site URL = адрес вашего GitHub Pages.
7. Откройте сайт, зарегистрируйтесь с почтой из пункта 2 — в шапке появится «Управление». Дальше всё (песни, MP3, обложки, записи, пользователи) делается там.
Лимиты Free: 1 ГБ файлов, файл до 50 МБ, 5 ГБ трафика/мес; проект засыпает после 7 дней без активности (восстанавливается кнопкой в панели Supabase).
